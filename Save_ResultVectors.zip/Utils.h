#pragma once
#include <iostream>
#include <vector>
#include <cstdlib>
#include <chrono>

#include <unordered_map>

#include "lodepng.h"



class rgb
{
public:
	rgb() {
		_rgb[0] = 0;
		_rgb[1] = 0;
		_rgb[2] = 0;
	};

	rgb(double _r, double _g, double _b) {
		_rgb[0] = _r;
		_rgb[1] = _g;
		_rgb[2] = _b;
	}

	void display() {
		std::cout << "(" << _rgb[0] << ", " << _rgb[1] << ", " << _rgb[2] << ")";
	}

	bool operator==(const rgb& _pixel) const
	{
		return (_rgb[0] == _pixel._rgb[0] && _rgb[1] == _pixel._rgb[1] && _rgb[2] == _pixel._rgb[2]);
	}


	double _rgb[3];
};





class Img {
public:
	Img(){
		width = 0;
		height = 0;
	}

	Img(unsigned char* _pixels, unsigned _width, unsigned _height) {
		width = _width;
		height = _height;
		pixels = (unsigned char*)malloc(width * height * 4 * sizeof(unsigned char));
		if (pixels) {
			for (int i = 0; i < width * height * 4; i++) {
				pixels[i] = _pixels[i];
			}
		}
		else {
			std::cout << "Error allocating memory for the image.\n";
		}
	}

	Img(Img& _img) {
		width = _img.width;
		height = _img.height;
		pixels = (unsigned char*)malloc(width * height * 4 *sizeof(unsigned char));
		if (pixels) {
			for (int i = 0; i < width * height * 4; i++) {
				pixels[i] = _img.pixels[i];
			}
		}
		else {
			std::cout << "Error allocating memory for the image.\n";
		}
	}

	~Img() {
		free(pixels);
	}

	unsigned width;
	unsigned height;
	unsigned char* pixels = 0;	// Contains width * height * 4 chars
};



class Block {
public:
	Block(std::string _id, rgb _light, rgb _flat, rgb _dark);
	void display();

	std::string id;
	rgb light;
	rgb flat;
	rgb dark;
};

class Palette {
public:
	Palette();
	Palette(std::vector<Block> _blocks);
	~Palette() {
		//free(bfb_gamut);
		//free(tfb_gamut);
		//free(bft_gamut);

		free(bfb);
		free(tfb);
		free(bft);

		free(bottom_flat);
		free(top_light);
		free(bottom_dark);
		//std::cout << "deleted objects";
	}

	//void computeGamut(rgb* colors, rgb* gamut);

	//void computeAllGamuts();

	void flatten(double* pixelArray, rgb* colors);

	rgb cap(rgb* color);

	void errDiff(double* err, rgb* diff, rgb* c1, rgb* c2);

	void findBest(int* bestCol, double* bestErr, rgb* bestDiff, rgb* color, int shade);

	std::vector<Block> blocks;

	rgb* bottom_flat;
	rgb* top_light;
	rgb* bottom_dark;
	int nbCol;

	//rgb* bfb_gamut;	// Darkest and brightest R, G and B among all colors
	//rgb* tfb_gamut;
	//rgb* bft_gamut;

	double* bfb;	// Below from below		[r0,g0,b0,r1,g1,b1,...]
	double* tfb;	// Top from below
	double* bft;	// Below from top
};

class CacheKey {
public:
	CacheKey(int _pos,	int _lastHeight, int _lastBlock, rgb _pixel) {
		pos = _pos;
		lastHeight = _lastHeight;
		lastBlock = _lastBlock;
		pixel = _pixel;
	};

	bool operator==(const CacheKey& _key) const
	{
		return (pos == _key.pos && lastHeight == _key.lastHeight && lastBlock == _key.lastBlock && pixel == _key.pixel);
	}

	int pos;
	int lastHeight;
	int lastBlock;
	rgb pixel;

};

template <class T>
inline void hash_combine(std::size_t& seed, const T& v)
{
	std::hash<T> hasher;
	seed ^= hasher(v) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}

template <>
struct std::hash<CacheKey>
{
	std::size_t operator()(const CacheKey& k) const
	{
		std::size_t seed = 0;
		hash_combine(seed, k.pos);
		hash_combine(seed, k.lastHeight);
		hash_combine(seed, k.lastBlock);
		hash_combine(seed, k.pixel._rgb[0]);
		hash_combine(seed, k.pixel._rgb[1]);
		hash_combine(seed, k.pixel._rgb[2]);	// Pretty bad hash...
		return seed;
	}
};

struct compareCacheKey {
	bool operator() (const CacheKey& a, const CacheKey& b) const {
		return (a.pos < b.pos) ||
			(a.pos == b.pos && a.lastHeight < b.lastHeight) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock < b.lastBlock) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] < b.pixel._rgb[0]) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] == b.pixel._rgb[0] && a.pixel._rgb[1] < b.pixel._rgb[1]) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] == b.pixel._rgb[0] && a.pixel._rgb[1] == b.pixel._rgb[1] && a.pixel._rgb[2] < b.pixel._rgb[2]);
	}
};

class Result {
public:
	Result();
	Result(bool _sucess);

	std::vector<int> bestBlocks;
	std::vector<int> bestHeights;
	std::vector<rgb> bestDiffs;
	double bestErr = 9999999;
	bool success = false;
};


class Process {
public:
	Process(Palette* _palette);
	~Process() {
		delete initImg;
		delete preprocessedImg;
		delete ditheredImg;
	}

	void findFileName(std::string path);
	void decodePng(const char* path);
	void encodePng(const char* path);
	void preprocess(int _nx, int _ny, int offsetx, int offsety);	// Img pre-processing to fit the map standard
	Result memoCollumnDitherDiffuse(int pos, int end, int lastHeight, int lastBlock, rgb lastErr);
	bool dither();			// Dither img and store result in ditheredImg

	Palette* palette;

	//std::map<CacheKey, Result, compareCacheKey> memocache;
	std::unordered_map<CacheKey, Result> memocache;
	int memoSize = 0;
	unsigned char* currentColumn;
	double* errorMap;

	Img* initImg;			// Initial image
	Img* preprocessedImg;	// Resized image
	Img* ditheredImg;		// Final dithered image
	int nx;					// Number of maps along x
	int ny;					// Number of maps along y
	std::string fileName;

	int maxDepth = 950;
	int maxCache = 200000;
	int maxheight = 1;
	bool noDither = false;
};
