#include "Utils.h"



Block::Block(std::string _id, rgb _light, rgb _flat, rgb _dark) {
	id = _id;
	light = _light;
	flat = _flat;
	dark = _dark;
}

void Block::display() {
	std::cout << id << ", light shade : "; light.display(); std::cout << ", flat shade : "; flat.display(); std::cout << ", dark shade : "; dark.display();
}





//void Palette::computeGamut(rgb* colors, rgb* gamut) {
//	// Find the brightest and darkest value for R G and B channels in the given palette
//	rgb brighest(0, 0, 0);
//	rgb darkest(255, 255, 255);
//	for (int col = 0; col < nbCol; col++) {
//		for (int shade = 0; shade < 3; shade++) {
//			if (colors[col]._rgb[shade] > brighest._rgb[shade])
//				brighest._rgb[shade] = colors[col]._rgb[shade];
//			if (colors[col]._rgb[shade] < darkest._rgb[shade])
//				darkest._rgb[shade] = colors[col]._rgb[shade];
//		}
//	}
//	gamut[0] = darkest;
//	gamut[1] = brighest;
//}


//void Palette::computeAllGamuts() {
//	computeGamut(bottom_flat, bfb_gamut);
//	computeGamut(top_light, tfb_gamut);
//	computeGamut(bottom_dark, bft_gamut);
//}

void Palette::flatten(double* pixelArray, rgb* colors) {
	for (int col = 0; col < nbCol; col++) {
		for (int i = 0; i < 3; i++) {
			pixelArray[3*col + i] = (colors[col]._rgb[i]);
		}
	}
}

Palette::Palette() {}					// PAS BON DOIT INITIALISER LES VARIABLES, MAIS JAMAIS APPELE

Palette::Palette(std::vector<Block> _blocks) {

	nbCol = _blocks.size();
	bottom_flat = (rgb*)malloc(nbCol * sizeof(rgb));
	top_light = (rgb*)malloc(nbCol * sizeof(rgb));
	bottom_dark = (rgb*)malloc(nbCol * sizeof(rgb));
	for (int i = 0; i < nbCol; i++) {
		bottom_flat[i] = _blocks[i].flat;
		top_light[i] = _blocks[i].light;
		bottom_dark[i] = _blocks[i].dark;
	}
	
	//bfb_gamut = (rgb*)malloc(2 * sizeof(rgb));
	//tfb_gamut = (rgb*)malloc(2 * sizeof(rgb));
	//bft_gamut = (rgb*)malloc(2 * sizeof(rgb));
	//computeAllGamuts();


	bfb = (double*)malloc(nbCol * 3 * sizeof(double));
	tfb = (double*)malloc(nbCol * 3 * sizeof(double));
	bft = (double*)malloc(nbCol * 3 * sizeof(double));
	flatten(bfb, bottom_flat);
	flatten(tfb, top_light);
	flatten(bft, bottom_dark);

	blocks = _blocks;
}


rgb Palette::cap(rgb* color) {
	rgb retCol = *color;
	for (int i = 0; i < 3; i++) {
		if (retCol._rgb[i] < 0)
			retCol._rgb[i] = 0;
		if (retCol._rgb[i] > 255)
			retCol._rgb[i] = 255;
	}
	return retCol;
}


void Palette::errDiff(double* err, rgb* diff, rgb* c1, rgb* c2) {
	*err = (c1->_rgb[0] - c2->_rgb[0]) * (c1->_rgb[0] - c2->_rgb[0]) + (c1->_rgb[1] - c2->_rgb[1]) * (c1->_rgb[1] - c2->_rgb[1]) + (c1->_rgb[2] - c2->_rgb[2]) * (c1->_rgb[2] - c2->_rgb[2]);
	*diff = rgb(c1->_rgb[0]- c2->_rgb[0], c1->_rgb[1] - c2->_rgb[1], c1->_rgb[2] - c2->_rgb[2]);
}

void Palette::findBest(int* bestCol, double* bestErr, rgb* bestDiff, rgb* color, int shade) {
	// Old implementation, loops through all colors
	// Should create a search tree for binary search to reduce complexity
	// Problem is equivalent to closest neighbour search in 3D space
	double err = 0;
	rgb diff;
	rgb capped = cap(color);

	*bestDiff = rgb(0, 0, 0);
	*bestErr = 9999999;
	*bestCol = 0;
	double* pal;
	if (shade == 0) {
		pal = tfb;
	}
	else if (shade == 1) {
		pal = bfb;
	}
	else {
		pal = bft;
	}
	rgb col_i;
	for (int i = 0; i < nbCol * 3; i+=3) {
		col_i._rgb[0] = pal[i];
		col_i._rgb[1] = pal[i + 1];
		col_i._rgb[2] = pal[i + 2];
		errDiff(&err, &diff, &capped, &col_i);
		if (err < *bestErr) {
			*bestErr = err;
			*bestCol = i/3;
			*bestDiff = diff;
		}
	}
}


Result::Result() {}


Result::Result(bool _sucess) {
	success = _sucess;
}








Process::Process(Palette* _palette) {
	palette = _palette;
}

void Process::findFileName(std::string path) {
	int lastIndex = 0;
	for (int i = 0; i < path.size(); i++) {
		if (path[i] == '\\') {
			lastIndex = i;
		}	
	}
	fileName = path.substr(lastIndex+1);
}


void Process::decodePng(const char* path) {
	// Reads image as std::vector, 4 bytes per pixel, R-G-B-A
	findFileName(path);
	initImg = new Img();
	unsigned error = lodepng_decode32_file(&initImg->pixels, &initImg->width, &initImg->height, path);
	if (error) std::cout << "Png decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
}

void Process::encodePng(const char* path) {
	unsigned error = lodepng_encode32_file(path, ditheredImg->pixels, ditheredImg->width, ditheredImg->height);
	if (error) std::cout << "Png encoder error " << error << ": " << lodepng_error_text(error) << std::endl;
}


void Process::preprocess(int _nx, int _ny, int offsetx, int offsety) {
	nx = _nx;
	ny = _ny;
	preprocessedImg = new Img(initImg->pixels, nx * 128, ny * 128);
}






Result Process::memoCollumnDitherDiffuse(int pos, int end, int lastHeight, int lastBlock, rgb lastErr) {
	if (pos == end) {
		return Result(true);
	}

	rgb pixel((double)currentColumn[pos*3] + errorMap[pos*3] + lastErr._rgb[0],
			  (double)currentColumn[pos*3+1] + errorMap[pos*3+1] + lastErr._rgb[1],
			  (double)currentColumn[pos*3+2] + errorMap[pos*3+2] + lastErr._rgb[2]);

	CacheKey cachekey(pos, lastHeight, lastBlock, pixel);

	//std::chrono::time_point<std::chrono::high_resolution_clock> t0 = std::chrono::high_resolution_clock::now();
	if (memocache.contains(cachekey)) {
		std::cout << "Cache reused" << std::endl;
		return memocache[cachekey];
	}
	//std::chrono::time_point<std::chrono::high_resolution_clock> t1 = std::chrono::high_resolution_clock::now();
	//std::cout << "Contain check :" << std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count() << "ns\n";

	//t0 = std::chrono::high_resolution_clock::now();
	if (memoSize > maxCache) {
		return Result(false);
	}
	//t1 = std::chrono::high_resolution_clock::now();
	//std::cout << "Size check :" << std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count() << "ns\n";


	int bestColSame, bestColBelow, bestColAbove;
	double bestErrSame, bestErrBelow, bestErrAbove;
	rgb bestDiffSame, bestDiffBelow, bestDiffAbove;
	/*std::chrono::time_point<std::chrono::high_resolution_clock> t0 = std::chrono::high_resolution_clock::now();*/
	palette->findBest(&bestColBelow, &bestErrBelow, &bestDiffBelow, &pixel, 0);
	palette->findBest(&bestColSame, &bestErrSame, &bestDiffSame, &pixel, 1);
	palette->findBest(&bestColAbove, &bestErrAbove, &bestDiffAbove, &pixel, 2);
	//std::chrono::time_point<std::chrono::high_resolution_clock> t1 = std::chrono::high_resolution_clock::now();
	//std::cout << "Find Best color :" << std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count() << "ns\n";

	int bestBlock = 0;
	int bestHeight = 0;
	double bestErr = 99999999999;
	rgb bestDiff;
	Result bestCont(true);

	for (int height = 0;height < maxheight; height++) {
		double err = 0;
		rgb diff;
		int block = 0;

		if (lastHeight == -1) {
			err = 0;
			diff = rgb();
			block = 0;
		}
		else if (height == lastHeight) {
			err = bestErrSame;
			diff = bestDiffSame;
			block = bestColSame;
		}
		else if (height > lastHeight) {
			err = bestErrBelow;
			diff = bestDiffBelow;
			block = bestColBelow;
		}
		else if (height < lastHeight) {
			err = bestErrAbove;
			diff = bestDiffAbove;
			block = bestColAbove;
		}

		rgb nextErr = rgb(diff._rgb[0] * 7/16, diff._rgb[1] * 7/16, diff._rgb[2] * 7/16);	// South error diffusion (Floyd Steinberg)
		
		Result continuation = memoCollumnDitherDiffuse(pos+1, end, height, block, nextErr);

		if (!continuation.success) {
			return Result(false);
		}

		if (continuation.bestErr + err < bestErr) {
			bestBlock = block;
			bestErr = continuation.bestErr + err;
			bestDiff = diff;
			bestHeight = height;
			bestCont = continuation;
		}
	}

	bestCont.bestBlocks.push_back(bestBlock);
	bestCont.bestHeights.push_back(bestHeight);
	bestCont.bestDiffs.push_back(bestDiff);
	bestCont.bestErr = bestErr;

	memocache.insert({ cachekey , bestCont });
	memoSize += 1;
	
	return bestCont;
}




struct Tuple{
	int first;
	int second;
};



bool Process::dither() {
	ditheredImg = new Img(*preprocessedImg);	// Copy preprocessed img as initializer
	// Initialize the image to black with no transparency
	for (int progress = 0; progress < (int)ditheredImg->width; progress++) {
		for (int row = 0; row < (int)ditheredImg->height; row++) {
			for (int i = 0; i < 3; i++) {
				ditheredImg->pixels[4 * (row * ditheredImg->width + progress)+i] = 0;
			}
			ditheredImg->pixels[4 * (row * ditheredImg->width + progress) + 3] = 255;
		}
	}



	if (noDither) {					// Best match for each pixel, no dithering
		rgb currentColor;
		static double bestErr;
		static rgb bestDiff;
		static int bestCol;
		for (int progress = 0; progress < (int)ditheredImg->width; progress++) {
			for (int row = 0; row < (int)ditheredImg->height; row++) {
				currentColor = rgb(preprocessedImg->pixels[4 * (row * ditheredImg->width + progress)], preprocessedImg->pixels[4 * (row * ditheredImg->width + progress) + 1], preprocessedImg->pixels[4 * (row * ditheredImg->width + progress) + 2]);
				palette->findBest(&bestCol, &bestErr, &bestDiff, &currentColor, 1);
				for (int i = 0; i < 3; i++) {
					ditheredImg->pixels[4 * (row * ditheredImg->width + progress) + i] = palette->bfb[3 * bestCol + i];
				}
			}
		}

		return true;
	}


	else // Floyd Steinberg dithering
	{
		


		//if (maxheight == 0) {	// 1 Layer/Flat dithering
		//	rgb currentColor;
		//	static double bestErr;
		//	static rgb bestDiff;
		//	static int bestCol;

		//	for (int column = 0; column < (int)ditheredImg->width; column++) {
		//		for (int row = 0; row < (int)ditheredImg->height; row++) {
		//			errorMap.push_back(0);
		//			errorMap.push_back(0);
		//			errorMap.push_back(0);
		//		}
		//	}
		//	for (int column = 0; column < (int)ditheredImg->width; column++){
		//		for (int row = 0; row < (int)ditheredImg->height; row++) {
		//			currentColor = rgb(preprocessedImg->pixels[4 * (row * ditheredImg->width + column)] + errorMap[3 * (row * ditheredImg->width + column)], preprocessedImg->pixels[4 * (row * ditheredImg->width + column) + 1] + errorMap[3 * (row * ditheredImg->width + column) + 1], preprocessedImg->pixels[4 * (row * ditheredImg->width + column) + 2] + errorMap[3 * (row * ditheredImg->width + column) + 2]);
		//			palette.findBest(&bestCol, &bestErr, &bestDiff, currentColor, palette.bfb);

		//			for (int i = 0; i < 3; i++) {
		//				ditheredImg->pixels[4 * (row * ditheredImg->width + column) + i] = palette.bfb[3 * bestCol + i];	// Apply best color to pixel
		//				
		//				if (column < (int)ditheredImg->width - 1) {
		//					errorMap[3 * (row * ditheredImg->width + (column + 1)) + i] += bestDiff._rgb[i] * 5/16;	// East
		//					if (row > 0) {
		//						errorMap[3 * ((row - 1) * ditheredImg->width + (column + 1)) + i] += bestDiff._rgb[i] * 3/16; // North East	
		//					}
		//				}
		//				if (row < (int)ditheredImg->height - 1) {
		//					errorMap[3 * ((row + 1) * ditheredImg->width + column) + i] += bestDiff._rgb[i] * 7/16;	// South
		//					if (column < (int)ditheredImg->width - 1) {
		//						errorMap[3 * ((row + 1) * ditheredImg->width + (column + 1)) + i] += bestDiff._rgb[i] * 1/16;	// South East
		//					}
		//				}
		//			}
		//			ditheredImg->pixels[4 * (row * ditheredImg->width + column) + 3] = 255;
		//		}
		//	}
		//	return true;
		//}











		currentColumn = (unsigned char*)malloc((int)(ditheredImg->height + 2) * 3 * sizeof(unsigned char));

		double* nextErrorMap = (double*)malloc((int)(ditheredImg->height + 2) * 3 * sizeof(double));
		errorMap = (double*)malloc((int)(ditheredImg->height + 2) * 3 * sizeof(double));
		for (int i = 0; i < (int)(ditheredImg->height+2)*3; i++) {
			nextErrorMap[i] = 0;
		}
		
		rgb diff;
		int totalErr = 0;

		int* finalBlockMap = (int*)malloc((int)preprocessedImg->width * ((int)preprocessedImg->height + 1) * sizeof(int));	// Column per column and padding
		int* finalHeightMap = (int*)malloc((int)preprocessedImg->width * ((int)preprocessedImg->height + 1) * sizeof(int));	// Same

		srand(0);	// Same seed everytime

		for (int progress = 0; progress < (int)preprocessedImg->width; progress++) {	// For each column of the map

			currentColumn[0] = 0;	// Noobline padding
			currentColumn[1] = 0;
			currentColumn[2] = 0;
			for (int row = 0; row < (int)preprocessedImg->height; row++) {
				for (int i = 0; i < 3; i++) {
					currentColumn[3 + 3*row + i] = preprocessedImg->pixels[4 * (row * preprocessedImg->width + progress) + i];
				}
			}
			currentColumn[3 + (int)preprocessedImg->height * 3] = 0;	// Bottom padding for recursion
			currentColumn[4 + (int)preprocessedImg->height * 3] = 0;
			currentColumn[5 + (int)preprocessedImg->height * 3] = 0;

			int* blockmap = (int*)malloc(((int)preprocessedImg->height + 2) * sizeof(int));
			int* heightmap = (int*)malloc(((int)preprocessedImg->height + 2) * sizeof(int));

			blockmap[0] = progress % 16 - 1;	// Noobline block, rainbow

			
			for (int i = 0; i < (int)(ditheredImg->height + 2) * 3; i++) {
				errorMap[i] = nextErrorMap[i];
				nextErrorMap[i] = 0;
			}
			Result result(true);

			int lastHeight = -1;
			rgb lastErr;

			std::vector<Tuple> subdivisions;
			Tuple firstEl = { .first = 0, .second = (int)preprocessedImg->height + 1 };	// currentColumn.size()/3 - 1
			subdivisions.push_back(firstEl);

			while (subdivisions.size() > 0) {
				Tuple section = subdivisions.back();
				subdivisions.pop_back();

				int size = section.second - section.first;

				if (size > maxDepth) {		// Too tall to process
					std::cout << "Too tall to process\n";
					result.success = false;
				}
				else {
					memocache.clear();
					memoSize = 0;
					result = memoCollumnDitherDiffuse(section.first, section.second, lastHeight, -1, lastErr);
				}

				if (result.success == false) {
					int pivot = section.first + (int)(size/4) + rand() % (int)(size/2);
					Tuple firstSection = {.first = pivot, .second = section.second};
					Tuple secondSection = { .first = section.first, .second = pivot };
					subdivisions.push_back(firstSection);
					subdivisions.push_back(secondSection);
				}
				else {
					lastHeight = result.bestHeights[0];
					totalErr += result.bestErr;
					
					for (int i = section.first; i < section.second; i++) {
						blockmap[i] = result.bestBlocks.back();
						heightmap[i] = result.bestHeights.back();
						diff = result.bestDiffs.back();
						result.bestBlocks.pop_back();
						result.bestHeights.pop_back();
						result.bestDiffs.pop_back();

						int pos = 3 * i;

						errorMap[pos + 3] += diff._rgb[0] * 7 / 16; // South
						errorMap[pos + 4] += diff._rgb[1] * 7 / 16;
						errorMap[pos + 5] += diff._rgb[2] * 7 / 16;

						nextErrorMap[pos - 3] += diff._rgb[0] * 3 / 16; // North East
						nextErrorMap[pos - 2] += diff._rgb[1] * 3 / 16;
						nextErrorMap[pos - 1] += diff._rgb[2] * 3 / 16;

						nextErrorMap[pos] += diff._rgb[0] * 5 / 16;	// East
						nextErrorMap[pos + 1] += diff._rgb[1] * 5 / 16;
						nextErrorMap[pos + 2] += diff._rgb[2] * 5 / 16;

						nextErrorMap[pos + 3] += diff._rgb[0] * 1 / 16;	// South East
						nextErrorMap[pos + 4] += diff._rgb[1] * 1 / 16;
						nextErrorMap[pos + 5] += diff._rgb[2] * 1 / 16;
					}
				}
			}

			for (int row = 0; row < (int)preprocessedImg->height + 1; row++) {
				finalBlockMap[progress * ((int)preprocessedImg->height + 1) + row] =  blockmap[row];
				finalHeightMap[progress * ((int)preprocessedImg->height + 1) + row] = heightmap[row];
			}

			free(blockmap);
			free(heightmap);	//////// NOTE : COULD KEEP THOSE UNTIL THE END AND REWRITE ON THE PREVIOUS VALUES

			std::cout << progress + 1 << "/" << preprocessedImg->width << " Done\n";
		}

		free(nextErrorMap);
		free(errorMap);
		free(currentColumn);

		// Saving image and NBT
		for (int column = 0; column < (int)ditheredImg->width; column++) {

			int lastheight = finalHeightMap[column * ((int)ditheredImg->height + 2)];

			for (int row = 0; row < (int)ditheredImg->height; row++) {
				int blocktype = finalBlockMap[column * ((int)ditheredImg->height + 1) + row + 1];
				int height = finalHeightMap[column * ((int)ditheredImg->height + 1) + row + 1];
				
				int pixelPos = 4 * (row * ditheredImg->width + column);

				for (int i = 0; i < 3; i++) {	// Compact writing, but slower execution IMPROVE ON THIS BY COPY PASTING LINES OF CODE
					if (lastheight == height) { // Flat shade
						ditheredImg->pixels[pixelPos + i] = palette->blocks[blocktype].flat._rgb[i];
					}
					else if (lastheight < height) {	// Light shade
						ditheredImg->pixels[pixelPos + i] = palette->blocks[blocktype].light._rgb[i];
					}
					else {	// Dark shade
						ditheredImg->pixels[pixelPos + i] = palette->blocks[blocktype].dark._rgb[i];
					}
				}
				lastheight = height;
			}
		}

		free(finalBlockMap);
		free(finalHeightMap);
	}

	return true;
}
