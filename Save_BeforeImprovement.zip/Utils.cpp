#include "Utils.h"



Img::Img(std::vector<unsigned char> _pixels, unsigned _width, unsigned _height) {
	width = _width;
	height = _height;
	pixels = _pixels;
}





Block::Block(std::string _id, rgb _light, rgb _flat, rgb _dark) {
	id = _id;
	light = _light;
	flat = _flat;
	dark = _dark;
}

void Block::display() {
	std::cout << id << ", light shade : "; light.display(); std::cout << ", flat shade : "; flat.display(); std::cout << ", dark shade : "; dark.display();
}





std::vector<rgb> Palette::computeGamut(std::vector<rgb> colors) {
	// Find the brightest and darkest value for R G and B channels in the given palette
	rgb brighest(0, 0, 0);
	rgb darkest(255, 255, 255);
	for (const rgb& color : colors) {
		for (int shade = 0; shade < 3; shade++) {
			if (color._rgb[shade] > brighest._rgb[shade])
				brighest._rgb[shade] = color._rgb[shade];
			if (color._rgb[shade] < darkest._rgb[shade])
				darkest._rgb[shade] = color._rgb[shade];
		}
	}
	std::vector<rgb> ret = { darkest, brighest };
	return ret;
}


void Palette::computeAllGamuts() {
	bfb_gamut = computeGamut(bottom_flat);
	tfb_gamut = computeGamut(top_light);
	bft_gamut = computeGamut(bottom_dark);
}

void Palette::flatten(std::vector<double>* pixelArray, std::vector<rgb> colors) {
	for (const rgb& color : colors) {
		for (int i = 0; i < 3; i++) {
			pixelArray->push_back(color._rgb[i]);
		}
	}
}

Palette::Palette() {}

Palette::Palette(std::vector<Block> _blocks) {

	for (int i = 0; i < _blocks.size(); i++) {
		bottom_flat.push_back(_blocks[i].flat);
		top_light.push_back(_blocks[i].light);
		bottom_dark.push_back(_blocks[i].dark);
	}
	
	computeAllGamuts();

	flatten(&bfb, bottom_flat);
	flatten(&tfb, top_light);
	flatten(&bft, bottom_dark);

	for (int i = 0; i < 16; i++) {
		tfb_blocks.push_back(i);
		bfb_blocks.push_back(i);
		bft_blocks.push_back(i);
	}

	blocks = _blocks;
}


rgb Palette::cap(rgb color) {
	rgb retCol = color;
	for (int i = 0; i < 3; i++) {
		if (retCol._rgb[i] < rgbGamut[0]._rgb[i])
			retCol._rgb[i] = rgbGamut[0]._rgb[i];
		if (retCol._rgb[i] > rgbGamut[1]._rgb[i])
			retCol._rgb[i] = rgbGamut[1]._rgb[i];
	}
	return retCol;
}


void Palette::errDiff(double* err, rgb* diff, rgb c1, rgb c2) {
	*err = (c1._rgb[0] - c2._rgb[0]) * (c1._rgb[0] - c2._rgb[0]) + (c1._rgb[1] - c2._rgb[1]) * (c1._rgb[1] - c2._rgb[1]) + (c1._rgb[2] - c2._rgb[2]) * (c1._rgb[2] - c2._rgb[2]);
	*diff = rgb(c1._rgb[0]- c2._rgb[0], c1._rgb[1] - c2._rgb[1], c1._rgb[2] - c2._rgb[2]);
}

void Palette::findBest(int* bestCol, double* bestErr, rgb* bestDiff, rgb color, std::vector<double> pal) {
	// Old implementation, loops through all colors
	// Should create a search tree for binary search to reduce complexity
	// Problem is equivalent to closest neighbour search in 3D space

	double err = 0;
	rgb diff;
	rgb capped = cap(color);

	*bestDiff = rgb(0, 0, 0);
	*bestErr = 9999999;
	*bestCol = 0;

	for (int i = 0; i < pal.size(); i+=3) {
		rgb col_i = rgb(pal[i], pal[i+1], pal[i+2]);
		errDiff(&err, &diff, capped, col_i);
		if (err < *bestErr) {
			*bestErr = err;
			*bestCol = i/3;
			*bestDiff = diff;
		}
	}
}


Result::Result() {
	bestErr = 9999999;
	success = false;
}


Result::Result(bool _sucess) {
	bestErr = 9999999;
	success = _sucess;
}








Process::Process(Palette _palette) {
	nx = 0;
	ny = 0;
	palette = _palette;
}

void Process::findFileName(std::string path) {
	int lastIndex = 0;
	for (int i = 0; i < path.size(); i++) {
		if (path[i] == '\\') {
			lastIndex = i;
		}	
	}
	fileName = path.substr(lastIndex+1);
}


void Process::decodePng(const char* path) {
	// Reads image as std::vector, 4 bytes per pixel, R-G-B-A
	findFileName(path);
	unsigned error = lodepng::decode(initImg.pixels, initImg.width, initImg.height, path);



	if (error) std::cout << "Png decoder error " << error << ": " << lodepng_error_text(error) << std::endl;
}

void Process::encodePng(const char* path) {
	unsigned error = lodepng::encode(path, ditheredImg.pixels, ditheredImg.width, ditheredImg.height);
	if (error) std::cout << "Png encoder error " << error << ": " << lodepng_error_text(error) << std::endl;
}


void Process::preprocess(int _nx, int _ny, int offsetx, int offsety) {
	nx = _nx;
	ny = _ny;
	preprocessedImg = Img(initImg.pixels, nx * 128, ny * 128);
}






Result Process::memoCollumnDitherDiffuse(int pos, int end, int lastHeight, int lastBlock, rgb lastErr) {
	//std::cout << "pos : " << pos << std::endl;
	if (pos == end) {
		//std::cout << "Segment of size 0" << std::endl;
		return Result(true);
	}

	rgb pixel((double)currentColumn[pos*3] + errorMap[pos*3] + lastErr._rgb[0],
			  (double)currentColumn[pos*3+1] + errorMap[pos*3+1] + lastErr._rgb[1],
			  (double)currentColumn[pos*3+2] + errorMap[pos*3+2] + lastErr._rgb[2]);

	CacheKey cachekey(pos, lastHeight, lastBlock, pixel);
	//pixel.display();
	//std::cout << "\n";

	//std::chrono::time_point<std::chrono::system_clock> t0 = std::chrono::system_clock::now();
	if (memocache.contains(cachekey)) {
		//std::cout << "Cache reused" << std::endl;
		return memocache[cachekey];
	}
	//std::chrono::time_point<std::chrono::system_clock> t1 = std::chrono::system_clock::now();
	//std::cout << std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count() << "ns\n";

	if (memocache.size() > maxCache) {
		//std::cout << "Max cache reached" << std::endl;
		return Result(false);
	}

	int bestColSame, bestColBelow, bestColAbove;
	double bestErrSame, bestErrBelow, bestErrAbove;
	rgb bestDiffSame, bestDiffBelow, bestDiffAbove;

	palette.findBest(&bestColSame, &bestErrSame, &bestDiffSame, pixel, palette.bfb);
	palette.findBest(&bestColBelow, &bestErrBelow, &bestDiffBelow, pixel, palette.tfb);
	palette.findBest(&bestColAbove, &bestErrAbove, &bestDiffAbove, pixel, palette.bft);

	int bestBlock = 0;
	int bestHeight = 0;
	double bestErr = 99999999999;
	rgb bestDiff;
	Result bestCont(true);

	for (int height = 0; height < maxheight; height++) {
		double err = 0;
		rgb diff;
		int block = 0;

		if (lastHeight == -1) {
			err = 0;
			diff = rgb();
			block = 0;
		}
		else if (height == lastHeight) {
			err = bestErrSame;
			diff = bestDiffSame;
			block = palette.bfb_blocks[bestColSame];
		}
		else if (height > lastHeight) {
			err = bestErrBelow;
			diff = bestDiffBelow;
			block = palette.tfb_blocks[bestColBelow];
		}
		else if (height < lastHeight) {
			err = bestErrAbove;
			diff = bestDiffAbove;
			block = palette.bft_blocks[bestColAbove];
		}

		rgb nextErr = rgb(diff._rgb[0] * 7/16, diff._rgb[1] * 7/16, diff._rgb[2] * 7/16);	// South error diffusion (Floyd Steinberg)
		
		Result continuation = memoCollumnDitherDiffuse(pos+1, end, height, block, nextErr);

		if (!continuation.success) {
			//std::cout << "Not successful" << std::endl;
			return Result(false);
		}

		if (continuation.bestErr + err < bestErr) {
			bestBlock = block;
			bestErr = continuation.bestErr + err;
			bestDiff = diff;
			bestHeight = height;
			bestCont = continuation;
		}
	}

	bestCont.bestBlocks.push_back(bestBlock);
	bestCont.bestHeights.push_back(bestHeight);
	bestCont.bestDiffs.push_back(bestDiff);
	bestCont.bestErr = bestErr;

	memocache.insert({ cachekey , bestCont });
	
	return bestCont;
}




struct Tuple{
	int first;
	int second;
};



bool Process::dither() {
	ditheredImg = Img(preprocessedImg);	// Copy preprocessed img as initializer
	// Initialize the image to black
	for (int progress = 0; progress < (int)ditheredImg.width; progress++) {
		for (int row = 0; row < (int)ditheredImg.height; row++) {
			for (int i = 0; i < 3; i++) {
				ditheredImg.pixels[4 * (row * ditheredImg.width + progress)+i] = 0;
			}
			ditheredImg.pixels[4 * (row * ditheredImg.width + progress) + 3] = 255;
		}
	}
	

	
	if (noDither) {
		rgb currentColor;
		static double bestErr;
		static rgb bestDiff;
		static int bestCol;
		for (int progress = 0; progress < (int)ditheredImg.width; progress++) {
			for (int row = 0; row < (int)ditheredImg.height; row++) {
				currentColor = rgb(preprocessedImg.pixels[4 * (row * ditheredImg.width + progress)], preprocessedImg.pixels[4 * (row * ditheredImg.width + progress) + 1], preprocessedImg.pixels[4 * (row * ditheredImg.width + progress) + 2]);
				palette.findBest(&bestCol, &bestErr, &bestDiff, currentColor, palette.bfb);
				for (int i = 0; i < 3; i++) {
					ditheredImg.pixels[4 * (row * ditheredImg.width + progress) + i] = palette.bfb[3 * bestCol + i];
				}
			}
		}
		return true;
	}
	else // Floyd Steinberg dithering
	{
		if (maxheight == 0) {	// 1 Layer/Flat dithering
			rgb currentColor;
			static double bestErr;
			static rgb bestDiff;
			static int bestCol;
			std::vector<int> errorMap;

			for (int column = 0; column < (int)ditheredImg.width; column++) {
				for (int row = 0; row < (int)ditheredImg.height; row++) {
					errorMap.push_back(0);
					errorMap.push_back(0);
					errorMap.push_back(0);
				}
			}
			for (int column = 0; column < (int)ditheredImg.width; column++){
				for (int row = 0; row < (int)ditheredImg.height; row++) {
					currentColor = rgb(preprocessedImg.pixels[4 * (row * ditheredImg.width + column)] + errorMap[3 * (row * ditheredImg.width + column)], preprocessedImg.pixels[4 * (row * ditheredImg.width + column) + 1] + errorMap[3 * (row * ditheredImg.width + column) + 1], preprocessedImg.pixels[4 * (row * ditheredImg.width + column) + 2] + errorMap[3 * (row * ditheredImg.width + column) + 2]);
					palette.findBest(&bestCol, &bestErr, &bestDiff, currentColor, palette.bfb);

					for (int i = 0; i < 3; i++) {
						ditheredImg.pixels[4 * (row * ditheredImg.width + column) + i] = palette.bfb[3 * bestCol + i];	// Apply best color to pixel
						
						if (column < (int)ditheredImg.width - 1) {
							errorMap[3 * (row * ditheredImg.width + (column + 1)) + i] += bestDiff._rgb[i] * 5/16;	// East
							if (row > 0) {
								errorMap[3 * ((row - 1) * ditheredImg.width + (column + 1)) + i] += bestDiff._rgb[i] * 3/16; // North East	
							}
						}
						if (row < (int)ditheredImg.height - 1) {
							errorMap[3 * ((row + 1) * ditheredImg.width + column) + i] += bestDiff._rgb[i] * 7/16;	// South
							if (column < (int)ditheredImg.width - 1) {
								errorMap[3 * ((row + 1) * ditheredImg.width + (column + 1)) + i] += bestDiff._rgb[i] * 1/16;	// South East
							}
						}
					}
					ditheredImg.pixels[4 * (row * ditheredImg.width + column) + 3] = 255;
				}
			}


			return true;
		}














		std::vector<double> nextErrorMap;
		for (int i = 0; i < (int)(ditheredImg.height+2)*3; i++) {
			nextErrorMap.push_back(0);
		}
		
		rgb diff;
		int totalErr = 0;

		std::vector<std::vector<int>> finalBlockMap;		// Completely unecessary REMAKE THIS SHIT
		std::vector<std::vector<int>> finalHeightMap;
		
		srand(0);	// Same seed everytime

		for (int progress = 0; progress < (int)preprocessedImg.width; progress++) {	// For each column of the map

			currentColumn.clear();
			currentColumn.push_back(0);	// Padding
			currentColumn.push_back(0);
			currentColumn.push_back(0);
			for (int row = 0; row < (int)preprocessedImg.height; row++) {
				for (int i = 0; i < 3; i++) {
					currentColumn.push_back(preprocessedImg.pixels[4 * (row * preprocessedImg.width + progress) + i]);
				}
			}
			currentColumn.push_back(0); // Padding
			currentColumn.push_back(0);
			currentColumn.push_back(0);

			std::vector<int> heightmap;
			std::vector<int> blockmap;
			heightmap.push_back(0);
			blockmap.push_back(progress % 16);	// Noobline block, rainbow

			errorMap = nextErrorMap;
			nextErrorMap.clear();
			for (int i = 0; i < (int)(ditheredImg.height+2) * 3; i++) {
				nextErrorMap.push_back(0);
			}
			Result result(true);

			int lastHeight = -1;
			rgb lastErr;
			std::vector<int> cacheSize;

			std::vector<Tuple> subdivisions;
			Tuple firstEl = { .first = 0, .second = (int)currentColumn.size() / 3 - 1 };
			subdivisions.push_back(firstEl);

			while (subdivisions.size() > 0) {
				Tuple section = subdivisions.back();
				subdivisions.pop_back();

				int size = section.second - section.first;

				if (size > maxDepth) {		// Too tall to process
					std::cout << "Too tall to process\n";
					result.success = false;
				}
				else {
					memocache.clear();
					result = memoCollumnDitherDiffuse(section.first, section.second, lastHeight, -1, lastErr);
					cacheSize.push_back(memocache.size());
				}

				if (result.success == false) {
					int pivot = section.first + (int)(size/4) + rand() % (int)(size/2);
					Tuple firstSection = {.first = pivot, .second = section.second};
					Tuple secondSection = { .first = section.first, .second = pivot };
					subdivisions.push_back(firstSection);
					subdivisions.push_back(secondSection);
				}
				else {
					lastHeight = result.bestHeights[0];
					totalErr += result.bestErr;
					
					for (int i = section.first; i < section.second; i++) {
						blockmap.push_back(result.bestBlocks.back());
						heightmap.push_back(result.bestHeights.back());
						diff = result.bestDiffs.back();
						result.bestBlocks.pop_back();
						result.bestHeights.pop_back();
						result.bestDiffs.pop_back();

						int pos = 3 * i;

						errorMap[pos + 3] += diff._rgb[0] * 7 / 16; // South
						
						errorMap[pos + 4] += diff._rgb[1] * 7 / 16;
						errorMap[pos + 5] += diff._rgb[2] * 7 / 16;

						nextErrorMap[pos - 3] += diff._rgb[0] * 3 / 16; // North East
						nextErrorMap[pos - 2] += diff._rgb[1] * 3 / 16;
						nextErrorMap[pos - 1] += diff._rgb[2] * 3 / 16;

						nextErrorMap[pos] += diff._rgb[0] * 5 / 16;	// East
						nextErrorMap[pos + 1] += diff._rgb[1] * 5 / 16;
						nextErrorMap[pos + 2] += diff._rgb[2] * 5 / 16;

						nextErrorMap[pos + 3] += diff._rgb[0] * 1 / 16;	// South East
						nextErrorMap[pos + 4] += diff._rgb[1] * 1 / 16;
						nextErrorMap[pos + 5] += diff._rgb[2] * 1 / 16;
					}
				}
			}

			finalBlockMap.push_back(blockmap);
			finalHeightMap.push_back(heightmap);

			std::cout << progress + 1 << "/" << preprocessedImg.width << " Done\n";
		}


		// Saving image and NBT
		for (int column = 0; column < (int)ditheredImg.width; column++) {
			//std::cout << "col : " << column << " : ";

			int lastheight = finalHeightMap[column][0];

			for (int row = 0; row < (int)ditheredImg.height; row++) {
				int blocktype = finalBlockMap[column][row+2];
				int height = finalHeightMap[column][row];

				int pixelPos = 4 * (row * ditheredImg.width + column);
				for (int i = 0; i < 3; i++) {	// Compact writing, but slower execution
					if (lastheight == height) { // Flat shade
						ditheredImg.pixels[pixelPos + i] = palette.blocks[blocktype].flat._rgb[i];
					}
					else if (lastheight < height) {	// Light shade
						ditheredImg.pixels[pixelPos + i] = palette.blocks[blocktype].dark._rgb[i];		// !!!!!!!!!!!! BIZARRE ON DIRAIT QUE LES SHADES SONT INVERSEES
					}
					else {	// Dark shade
						ditheredImg.pixels[pixelPos + i] = palette.blocks[blocktype].light._rgb[i];
					}
				}
				lastheight = height;
			}
		}
	}

	return true;
}
