#pragma once
#include <iostream>
#include <vector>
#include <map>
#include <cstdlib>
#include <chrono>

#include "lodepng.h"



class rgb
{
public:
	rgb() {
		_rgb[0] = 0;
		_rgb[1] = 0;
		_rgb[2] = 0;
	};

	rgb(double _r, double _g, double _b) {
		_rgb[0] = _r;
		_rgb[1] = _g;
		_rgb[2] = _b;
	}

	void display() {
		std::cout << "(" << _rgb[0] << ", " << _rgb[1] << ", " << _rgb[2] << ")";
	}

	double r() {
		return _rgb[0];
	}

	double g() {
		return _rgb[1];
	}

	double b() {
		return _rgb[2];
	}


	double _rgb[3];
};





class Img {
public:
	Img(){
		width = 0;
		height = 0;
	}

	Img(std::vector<unsigned char> _pixels, unsigned _width, unsigned _height);

	Img(Img& _img) {
		pixels = _img.pixels;
		width = _img.width;
		height = _img.height;
	}

	unsigned width;
	unsigned height;
	std::vector<unsigned char> pixels;
};



class Block {
public:
	Block(std::string _id, rgb _light, rgb _flat, rgb _dark);
	void display();

	std::string id;
	rgb light;
	rgb flat;
	rgb dark;
};

class Palette {
public:
	Palette();
	Palette(std::vector<Block> _blocks);

	std::vector<rgb> computeGamut(std::vector<rgb> colors);

	void computeAllGamuts();

	void flatten(std::vector<double>*, std::vector<rgb> colors);

	rgb cap(rgb color);

	void errDiff(double* err, rgb* diff, rgb c1, rgb c2);

	void findBest(int* bestCol, double* bestErr, rgb* bestDiff, rgb color, std::vector<double> pal);

	std::vector<Block> blocks;

	std::vector<rgb> rgbGamut = { rgb(0,0,0), rgb(255,255,255) };

	std::vector<rgb> bottom_flat;
	std::vector<rgb> top_light;
	std::vector<rgb> bottom_dark;
	// top_flat same as bottom_flat

	std::vector<rgb> bfb_gamut;	// Darkest and brightest R, G and B among all colors
	std::vector<rgb> tfb_gamut;
	std::vector<rgb> bft_gamut;
	// tft_gamut same as bfb_gamut
	// afb_gamut unused
	// aft_gamut unused
	// afa_gamut unused

	std::vector<double> bfb;	// Below from below		[r0,g0,b0,r1,g1,b1,...]
	std::vector<double> tfb;	// Top from below
	std::vector<double> bft;	// Below from top
	// tft same as bfb
	// afa unused

	std::vector<int> tfb_blocks;	// [0-15]
	std::vector<int> bfb_blocks;	// [16-31]
	std::vector<int> bft_blocks;	// [32-47]

};

class CacheKey {
public:
	CacheKey(int _pos,	int _lastHeight, int _lastBlock, rgb _pixel) {
		pos = _pos;
		lastHeight = _lastHeight;
		lastBlock = _lastBlock;
		pixel = _pixel;
	};

	int pos;
	int lastHeight;
	int lastBlock;
	rgb pixel;
};

struct compareCacheKey {
	bool operator() (const CacheKey& a, const CacheKey& b) const {
		return (a.pos < b.pos) ||
			(a.pos == b.pos && a.lastHeight < b.lastHeight) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock < b.lastBlock) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] < b.pixel._rgb[0]) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] == b.pixel._rgb[0] && a.pixel._rgb[1] < b.pixel._rgb[1]) ||
			(a.pos == b.pos && a.lastHeight == b.lastHeight && a.lastBlock == b.lastBlock && a.pixel._rgb[0] == b.pixel._rgb[0] && a.pixel._rgb[1] == b.pixel._rgb[1] && a.pixel._rgb[2] < b.pixel._rgb[2]);
	}
};

class Result {
public:
	Result();
	Result(bool _sucess);

	std::vector<int> bestBlocks;
	std::vector<int> bestHeights;
	std::vector<rgb> bestDiffs;
	double bestErr;
	bool success;
};


class Process {
public:
	Process(Palette _palette);
	void findFileName(std::string path);
	void decodePng(const char* path);
	void encodePng(const char* path);
	void preprocess(int _nx, int _ny, int offsetx, int offsety);	// Img pre-processing to fit the map standard
	Result memoCollumnDitherDiffuse(int pos, int end, int lastHeight, int lastBlock, rgb lastErr);
	bool dither();			// Dither img and store result in ditheredImg

	Palette palette;

	std::map<CacheKey, Result, compareCacheKey> memocache;
	std::vector<unsigned char> currentColumn;
	std::vector<double> errorMap;

	Img initImg;			// Initial image
	Img preprocessedImg;	// Resized image
	Img ditheredImg;		// Final dithered image
	int nx;					// Number of maps along x
	int ny;					// Number of maps along y
	std::string fileName;

	int maxDepth = 950;
	int maxCache = 200000;
	int maxheight = 1;
	bool noDither = false;
};
